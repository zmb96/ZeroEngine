package cn.ZeroEngine.Engine.api.v3.feature.screen;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.key.Key;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;
import io.papermc.paper.connection.PlayerConfigurationConnection;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.action.DialogAction;

import java.util.Collections;
import java.util.List;

public abstract class SScreen {

    private String namespace;
    protected Plugin plugin;

    public abstract String id();

    public abstract Component title();

    public List<DialogBody> body() { return Collections.emptyList(); }

    public List<DialogInput> inputs() { return Collections.emptyList(); }

    public boolean canCloseWithEscape() { return false; }

    public List<ActionButton> buttons() { return Collections.emptyList(); }

    public int columns() { return 1; }

    public ActionButton exitButton() { return null; }

    public DialogType type() {
        List<ActionButton> btns = buttons();
        ActionButton exit = exitButton();
        int n = btns.size();
        if (n == 0 && exit == null) {
            return DialogType.notice();
        }
        if (n == 1 && exit == null) {
            return DialogType.notice(btns.get(0));
        }
        if (n == 2 && exit == null) {
            return DialogType.confirmation(btns.get(0), btns.get(1));
        }
        return DialogType.multiAction(btns, exit, Math.max(1, columns()));
    }

    public boolean shouldShow(PlayerConfigurationConnection conn) { return true; }

    public boolean shouldShow(org.bukkit.entity.Player player) { return true; }

    public int timeoutSeconds() { return 60; }

    public int priority() { return 0; }

    public Class<? extends org.bukkit.event.Event> triggerEvent() { return null; }

    public String triggerCommand() { return null; }

    public abstract void onClick(ClickContext ctx);

    public Dialog buildDialog() {
        DialogBase.Builder baseBuilder = DialogBase.builder(title())
                .canCloseWithEscape(canCloseWithEscape());
        if (!body().isEmpty()) baseBuilder.body(body());
        if (!inputs().isEmpty()) baseBuilder.inputs(inputs());
        return Dialog.create(b -> b.empty()
                .base(baseBuilder.build())
                .type(type()));
    }

    protected ActionButton button(net.kyori.adventure.text.Component label, net.kyori.adventure.text.Component tooltip, String action) {
        ActionButton.Builder builder = ActionButton.builder(label);
        if (tooltip != null) builder.tooltip(tooltip);
        return builder.action(DialogAction.customClick(keyFor(action), null)).build();
    }

    protected ActionButton button(net.kyori.adventure.text.Component label, String action) {
        return button(label, null, action);
    }

    protected DialogInput textInput(String key, Component label) {
        return DialogInput.text(key, 100, label, true, "", 200, null);
    }

    protected DialogInput textInput(String key, Component label, int maxLength) {
        return DialogInput.text(key, maxLength, label, true, "", 200, null);
    }

    protected DialogInput textInput(String key, Component label, int maxLength, String initial) {
        return DialogInput.text(key, maxLength, label, true, initial, 200, null);
    }

    protected DialogInput textInput(String key, Component label, int maxLength, String initial, int width) {
        return DialogInput.text(key, maxLength, label, true, initial, width, null);
    }

    public final Key keyFor(String action) {
        String ns = (namespace == null || namespace.isEmpty()) ? "sf" : namespace;
        return Key.key(ns, id() + "/" + action);
    }

    public final String actionOf(NamespacedKey key) {
        if (key == null) return null;
        String expected = id() + "/";
        String value = key.value();
        int idx = value.indexOf(expected);
        if (idx < 0) return null;
        return value.substring(idx + expected.length());
    }

    public final String actionOf(net.kyori.adventure.key.Key key) {
        if (key == null) return null;
        String expected = id() + "/";
        String value = key.value();
        int idx = value.indexOf(expected);
        if (idx < 0) return null;
        return value.substring(idx + expected.length());
    }

    void bind(String namespace, Plugin plugin) {
        this.namespace = namespace;
        this.plugin = plugin;
    }

    public String namespace() { return namespace; }
}
